# HARUKA-MD

Website sewa bot WhatsApp elegan berbasis Flask (Python)

## Cara Jalankan Lokal
1. Clone atau download repo
2. Install dependensi:
    pip install -r requirements.txt
3. Jalankan:
    flask run

## Login Default
Admin:
- Email: admin@haruka-md.com
- Password: admin123

User:
- Email: user@haruka-md.com
- Password: user123
