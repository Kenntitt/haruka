from flask import Flask, render_template, redirect, url_for, request, session
from functools import wraps

app = Flask(__name__)
app.secret_key = 'supersecret'

# Dummy users
users = {
    'admin@haruka-md.com': {'password': 'admin123', 'role': 'admin'},
    'user@haruka-md.com': {'password': 'user123', 'role': 'user'}
}

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/pricing')
def pricing():
    return render_template('pricing.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = users.get(email)
        if user and user['password'] == password:
            session['user'] = {'email': email, 'role': user['role']}
            return redirect(url_for('dashboard'))
        return "Login gagal"
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    return "Fitur register disederhanakan di versi demo."

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', user=session['user'])

@app.route('/admin')
@login_required
def admin():
    if session['user']['role'] != 'admin':
        return "Akses ditolak"
    return render_template('admin.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
